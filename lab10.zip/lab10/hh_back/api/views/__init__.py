from .fbv import company_list, company_vacancies, company_detail
from .cbv import VacancyListAPIView, VacancyDetailsAPIView, VacancyTopTenAPIView
